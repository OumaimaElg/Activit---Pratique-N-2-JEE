package com.example.atelier2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atelier2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
